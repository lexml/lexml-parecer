# lexml-ui-commons
Web Components de uso comum aos editores de textos legislativos
